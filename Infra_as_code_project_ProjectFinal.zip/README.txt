he project consists of four files to deploy via cloudformation. Below is the instruction for deployment:
1- Run the network files first after executing the stack network
2-run the servers files.

